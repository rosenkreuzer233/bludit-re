<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="generator" content="Bludit CMS">
<?php echo Theme::metaTags('title'); ?>
<?php echo Theme::metaTags('description'); ?>
<?php echo Theme::favicon('img/logo.png'); ?>
<?php echo Theme::css('css/style.css'); ?>
<?php Theme::plugins('siteHead'); ?>
</head>
<body>

<?php Theme::plugins('siteBodyBegin'); ?>

<div class="wrapper">

<?php include(THEME_DIR_PHP.'header.php'); ?>

<?php
if ($WHERE_AM_I == 'page') {
include(THEME_DIR_PHP.'page.php');
} else {
include(THEME_DIR_PHP.'home.php');
}
?>

<?php include(THEME_DIR_PHP.'sidebar.php'); ?>
<?php include(THEME_DIR_PHP.'footer.php'); ?>

</div>

<link rel='stylesheet' id='google_opensans-css'  href='http://fonts.googleapis.com/css?family=Open+Sans%3A400%2C700&#038;ver=4.9.8' type='text/css' media='all' />
<link rel='stylesheet' id='google_ubuntu-css'  href='http://fonts.googleapis.com/css?family=Ubuntu%3A400%2C700&#038;ver=4.9.8' type='text/css' media='all' />

<?php
echo Theme::jquery();
echo Theme::js('js/js.js');
?>

<?php Theme::plugins('siteBodyEnd'); ?>

</body>
</html>