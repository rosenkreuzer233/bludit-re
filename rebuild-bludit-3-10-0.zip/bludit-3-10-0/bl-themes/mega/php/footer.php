<div class="footer">

<a class="footer-logo" href="<?php echo $site->url() ?>">
<img src="<?php echo DOMAIN_THEME_IMG.'logo.png'; ?>" alt="<?php echo $site->title() ?>"/>
</a>

<div class="copyright"><?php echo $site->footer(); ?></div>

<button class="up-button"></button>

</div>