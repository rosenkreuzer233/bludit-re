<div class="header">
<a class="logo" href="<?php echo $site->url() ?>">
<img src="<?php echo DOMAIN_THEME_IMG.'logo.png'; ?>" alt="<?php echo $site->title() ?>"/>
<span><?php echo $site->title() ?></span>
</a>
</div>