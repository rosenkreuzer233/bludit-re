<?php foreach ($content as $page): ?>

<?php Theme::plugins('pageBegin'); ?>

<?php if ($page->coverImage()): ?>
<a class="cover-image" href="<?php echo $page->permalink(); ?>">
<img alt="<?php echo $page->title(); ?>" src="<?php echo $page->coverImage(); ?>"/>
</a>
<?php endif ?>

<div class="wrapper-content">

<h2 class="title">
<a href="<?php echo $page->permalink(); ?>"><?php echo $page->title(); ?></a>
</h2>

<div class="date">
<?php echo $page->date(); ?> <span><?php echo $L->get('Reading time') . ': ' . $page->readingTime(); ?></span>
</div>

<div class="bord2"><span></span></div>

<?php if ($page->description()): ?>
<div class="content">
<p><?php echo $page->description(); ?></p>
</div>
<?php endif ?>

<a class="read-more" href="<?php echo $page->permalink(); ?>" role="button"><?php echo $L->get('Read more'); ?></a>

</div><!-- wrapper-content -->

<div class="bord"></div>

<?php Theme::plugins('pageEnd'); ?>

<?php endforeach ?>

<?php if (Paginator::numberOfPages()>1): ?>
<ul class="navigation">
<?php
if (Paginator::showPrev()) {
echo '<li class="previous"><a href="'.Paginator::previousPageUrl().'"></a></li>';
}
if (Paginator::showNext()) {
echo '<li class="next"><a href="'.Paginator::nextPageUrl().'"></a></li>';
}
?>
</ul>
<?php endif ?>