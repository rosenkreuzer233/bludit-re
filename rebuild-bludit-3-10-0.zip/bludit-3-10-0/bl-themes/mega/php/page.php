<?php Theme::plugins('pageBegin'); ?>

<?php if ($page->coverImage()): ?>
<img alt="<?php echo $page->title(); ?>" src="<?php echo $page->coverImage(); ?>"/>
<?php endif ?>

<div class="wrapper-content">

<h1 class="title">
<?php echo $page->title(); ?>
</h1>

<?php if (!$page->isStatic() && !$url->notFound()): ?>
<div class="date">
<?php echo $page->date(); ?> <span><?php echo $L->get('Reading time') . ': ' . $page->readingTime(); ?></span>
</div>
<div class="bord2"><span></span></div>
<?php endif ?>

<div class="content">
<?php echo $page->content(); ?>
</div>

<?php if ($page->category()):?>
<div class="bord3"><span></span></div>
<ul class="category">
<li>
<a href="<?php echo DOMAIN_CATEGORIES.$page->categoryKey() ?>">
<?php echo $page->category() ?>
</a>
</li>
</ul>
<?php endif?>

</div><!-- wrapper-content -->

<?php Theme::plugins('pageEnd'); ?>