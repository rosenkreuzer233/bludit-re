<button class="menu-button"></button>

<div class="header-navbar">
<a class="logo" href="<?php echo $site->url() ?>" title="<?php echo $site->slogan() ?>">
<img src="<?php echo DOMAIN_THEME_IMG.'logo.png'; ?>" alt="<?php echo $site->title() ?>"/>
<span><?php echo $site->title() ?></span>
</a>
</div>

<div class="sidebar">
<ul class="social-network">
<?php if ($site->github()): ?>
<li>
<a href="<?php echo $site->github() ?>" target="_blank" title="github">
<img src="<?php echo DOMAIN_THEME.'img/github.svg' ?>" alt="github icon" />
</a>
</li>
<?php endif ?>
<?php if ($site->twitter()): ?>
<li>
<a href="<?php echo $site->twitter() ?>" target="_blank" title="twitter">
<img src="<?php echo DOMAIN_THEME.'img/twitter.svg' ?>" alt="twitter icon" />
</a>
</li>
<?php endif ?>
<?php if ($site->facebook()): ?>
<li>
<a href="<?php echo $site->facebook() ?>" target="_blank" title="facebook">
<img src="<?php echo DOMAIN_THEME.'img/facebook.svg' ?>" alt="facebook icon" />
</a>
</li>
<?php endif ?>
<?php if ($site->googleplus()): ?>
<li>
<a href="<?php echo $site->googleplus() ?>" target="_blank" title="googleplus">
<img src="<?php echo DOMAIN_THEME.'img/googleplus.svg' ?>" alt="googleplus icon" />
</a>
</li>
<?php endif ?>
<?php if ($site->instagram()): ?>
<li>
<a href="<?php echo $site->instagram(); ?>" target="_blank" title="instagram">
<img src="<?php echo DOMAIN_THEME.'img/instagram.svg' ?>" alt="instgram icon" />
</a>
</li>
<?php endif ?>
<?php if ($site->codepen()): ?>
<li>
<a href="<?php echo $site->codepen() ?>" target="_blank" title="codepen">
<img src="<?php echo DOMAIN_THEME.'img/codepen.svg' ?>" alt="codepen icon" />
</a>
</li>
<?php endif ?>
<?php if ($site->linkedin()): ?>
<li>
<a href="<?php echo $site->linkedin() ?>" target="_blank" title="linkedin">
<img src="<?php echo DOMAIN_THEME.'img/linkedin.svg' ?>" alt="linkedin icon" />
</a>
</li>
<?php endif ?>
</ul>
<?php Theme::plugins('siteSidebar') ?>
</div>

<div class="overlay"></div>